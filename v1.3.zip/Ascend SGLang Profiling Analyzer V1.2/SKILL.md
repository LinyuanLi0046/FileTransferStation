---
name: ascend sglang profiling analyser
description: >
  为一个选定的 SGLang Ascend profiling 窗口重建代码路径并输出 kernel 到代码映射表。
  适用于 profiling 到代码对齐、逐 kernel 文件/函数/行定位，以及仅做轻量性能说明的分析场景。
---

# Ascend SGLang Profiling 分析器

## 目的

该 skill 用于为一个选定的 SGLang Ascend profiling 时间窗口重建运行时代码路径，将 profiling 证据与该路径严格对齐，并生成以表格为中心的 kernel 到代码映射报告。

## 总则

### 核心推理目标：

- 基于启动参数+模型config(包含arch+量化等)+代码进行运行完整代码执行路径重建
- profiling 到代码的严格对齐
- 逐 kernel 的kernel -> 文件:函数/代码行
  - 包含计算部分kernel以及运行时调度/控制相关kernel
- 重点是kernel->code的映射，仅保留直接帮助映射的轻量性能说明
  - 注意该 skill 不以宽泛问题清单、完整 host 侧诊断或完整 TPOT 优先级分析

### 原则

- 先重建代码路径，再做 profiling 到代码映射
- model forward 与运行时控制 / 调度 / graph 路径同等重要，必须一起分析
- 对通用小 kernel，先做 owner 竞争，不能只凭 kernel 名称归属
- 最终表格中凡是被展示的 kernel 行，都必须保持一行对应一个 kernel `row_id`
- 主计算部分允许按层实例折叠展示；但被保留层内部不得省略或合并 kernel 行
- 非主计算部分不得折叠，必须对所选窗口逐行完整保留

## 单一输入契约

该 skill 仅支持一种输入方案

必需输入：

- profiling 根路径
  - agent 必须在 `profiling_root_path/ASCEND_PROFILER_OUTPUT/` 下查找
  - 主原始证据必须为：
    - `trace_view.json`
    - `kernel_details.csv`
- 分析窗口起始+终止时间戳
  - `window_start_ns`
  - `window_end_ns`
  - 这些时间戳定义一个完整 token 级推理窗口
- 模型权重路径
  - 用于定位 `config.json`
  - 若存在则使用 `quant_model_description.json`（modelslim量化使用该文件）
- 本地代码仓路径
- 启动命令/脚本

可选输入：

- benchmark 命令
- benchmark 结果

## 单一 references 来源

`SKILL.md` 是规范性入口。`references/` 下仅保留与主规范配套的辅助文档：

- `references/pipeline.md`：阶段顺序、输入、输出与闸门
- `references/output_contract.md`：最终报告结构、表格粒度、coverage 对账与最终检查清单

`README.md` 仅作为使用指南与摘要。

## 固定预处理流水线

以下四个脚本作为证据准备层保持不变，并且每次完整分析都必须按固定顺序执行：

| 角色 | 脚本 |
|---|---|
| trace 切片 | `scripts/slice_profiling.py` |
| trace 初步处理+汇总 | `scripts/process_profiling.py` |
| kernel 切片 | `scripts/slice_kernel_csv.py` |
| kernel 初步处理+汇总 | `scripts/process_kernel.py` |

固定顺序：

1. 在 `profiling_root_path/ASCEND_PROFILER_OUTPUT/` 下定位完整原始 `trace_view.json` 与 `kernel_details.csv`
2. 按 `window_start_ns` 与 `window_end_ns` 切分原始 trace
3. 汇总切片 trace
4. 按相同窗口切分原始 kernel csv
5. 汇总切片 kernel csv

生成出的切片 trace、切片 kernel csv 以及相应汇总，仍然是后续流程的无损证据层。

## 执行流程

整体流水线流程：

1. 输入信息校验
2. 执行预处理
3. 模型 config 和启动参数检查
4. 单 token 推理路径重建
5. kernel 设备侧分析
6. 结构综合分析
7. 通用小 kernel owner 竞争分析
8. profiling 到代码对齐
9. kernel 代码映射表生成
10. review 生成的表格是否符合要求
11. 轻量性能分析
12. 报告生成

### 1. 输入信息校验

检查内容：

- 完整性
- 代码 / profiling / 模型权重路径是否真实存在
- 这些路径下是否有需要的内容
- 所给 start 和 end 时间戳是否有效

窗口契约：

- 不要直接将完整原始 profiling 抓取作为最终证据，必须使用用户提供的 ns 窗口，从完整原始 `trace_view.json` 与 `kernel_details.csv` 中切片
- 用户提供的 ns 窗口通常覆盖一个完整 token 推理 decode 窗口，包含计算部分 + 调度 / 控制 / graph update 相关步骤
- 对 MTP / speculative 场景，通常覆盖一个完整 `verify` + `draft_extend` + （若干个 `draft_decode`）+ 中间的请求 prepare / 调度控制 / graph update 等步骤
- 若缺少时间戳则必须停止并向用户索取

硬约束：

- 只允许上述单一输入契约
- 若缺少启动参数、代码路径、模型权重路径 / config、分析起始时间戳、profiling 中任何一个：
  - 明确拒绝继续进行任何处理和分析，引导用户给出符合要求的输入
- 没有真实启动参数前，不得开始严格代码定位

### 2. 执行预处理

执行内容：

- 执行 4 个脚本，对 trace 和 kernel 信息进行 slice + 初步处理总结

注意事项：

- 不得把用户提供的切片文件或派生汇总当成主 profiling 输入
- 不得直接分析完整原始 profiling 抓取，必须先按 ns 窗口切片
- 必须在 `profiling_root_path/ASCEND_PROFILER_OUTPUT/` 下发现原始 profiling 证据
- 必须同时使用 `trace_view.json` 与 `kernel_details.csv`
- 必须在严格映射前按固定顺序运行四个预处理脚本

### 3. 模型 config 和启动参数检查

检查内容：

- 参考上面的要求，注意模型 architecture、量化等部分
- 确定启动脚本中的启动参数

模型布局约束映射：

- 在可用时，使用 `config.json` 与 `quant_model_description.json` 约束以下内容：
  - 重复层数量
    - 是每层结构都一致，还是模型的总层数中有几种不同类型的层（例如 qwen3-next 模型有 1/4 的 full attention，3/4 的 linear attention）
  - 模型 architecture
    - attention 部分是 GQA or MLA or Linear Attention or 新架构
    - 是 dense 模型还是 MOE 模型，亦或是模型中二者皆有
    - MOE 路径是否有路由共享专家 / 零计算专家等特殊机制
  - 量化方式
    - 如 config.json 中 quantization 字段是 `modelslim`，则需检查 `quant_model_description.json` 中每个参数的量化方式
    - 可能模型中不同结构 / 不同层有不同的量化方式（例如 MLP 的 down proj 是 BF16，其他参数是 INT8；或者部分层是 BF16，部分层是 FP8）

以上信息用于和启动参数一起确定代码中理论执行路径。

### 4. 单 token 推理路径重建

核心目标：

- 基于启动参数 + 模型 config（包含 arch + 量化等）+ 代码进行运行完整代码执行路径重建

必须同时重建：

- model forward 路径
- 运行时控制 / 调度 / graph 路径

注意事项：

- 调度器、overlap、future-map、copy、sync、buffer-resolution 与 submission 逻辑都属于 token 路径的一部分，必须与 model-forward 一起重建
- 必须先重建 token 路径再做严格映射
- 对 speculative 或 overlap 较重运行，必须同时重建 runtime-control 与 model-forward

对 overlap 较重的运行，必须显式检查以下语义运行时子阶段：

- future resolution into current batch
- metadata 或 block-table 准备
- verify body handoff
- accept 或 sampling
- tree / cache / scheduler writeback

如果启动参数或代码表明存在 overlap、speculative 调度或 future-buffer 使用，最终报告必须明确这些子阶段是：

- 已观察到
- 检查后不存在
- 只能部分定位

### 5. kernel 设备侧分析

执行内容：

- 对窗口内 kernel 设备侧执行情况进行分析，作为后续结构综合与映射依据

### 6. 结构综合分析

执行内容：

- 结合 trace 与 kernel 结构，综合判断代码路径、阶段边界、重复层模式以及调度 / 控制 / graph update 相关区域

### 7. 通用小 kernel owner 竞争分析

执行内容：

- 对轻量通用小 kernel 簇进行 owner 竞争判断

通用小 kernel 先做 owner 竞争：

- 对轻量数据重组簇，应优先当作数据流解析问题而非直接命名归属问题处理。这包括 indexing、slicing、gather、scatter、copy、view change、range construction 与 metadata materialization 等

owner 优先级：

1. `scheduler / overlap / future-map`
2. `speculative-preparation`
3. `model-forward`

候选 owner 比较至少要考虑：

- phase 匹配
- 邻域模式匹配
- 在可恢复时的 shape / dtype 匹配
- buffer provenance 匹配
- 代码路径可达性

若没有任何 owner 足以解释整个簇，就应拆分或降级，而不是粗暴折叠成一个标签。

Future-map 检查是语义检查：

- 当存在 overlap 调度、speculative decoding、延迟 sampling 或 future-buffer 使用时，必须显式检查与以下语义等价的阶段：
  - future slot / future index allocation
  - future-buffer resolution into current batch
  - result storeback to future buffers
  - delayed sampling / delayed materialization
  - 保护这些阶段的 stream 或 host handoff 点
- 如下模式是附近通用运行时簇的一等 owner 证据：
  - `future_indices`
  - `buf[indices]`
  - `index_select`
  - `record_stream(...)`
  - `resolve_future(...)`
  - `store_to_map(...)`

硬约束：

- 未显式检查 `runtime_future_resolve` 时，不允许对附近通用运行时簇做严格 owner 断言
- 存在 overlap / future-map / speculative 调度时，必须显式检查 `runtime_future_resolve`
- 不得跳过 scheduler / overlap / future-map owner 竞争
- 不得把通用运行时工作粗暴压成 `spec_prepare`

### 8. profiling 到代码对齐

核心目标：

- profiling 到代码的严格对齐
- 逐 kernel 的 kernel -> 文件:函数 / 代码行
  - 包含计算部分 kernel 以及运行时调度 / 控制相关 kernel

按局部模式 + 所处阶段进行 kernel -> code 映射：

- 绝不能仅依赖一个 kernel 名称来定位代码。匹配单元必须是由以下信息构成的局部执行模式：
  - Kernel 名称
  - 左右相邻 kernels
  - 相邻 trace spans
  - 相对顺序
  - phase 或 layer 上下文
  - tensor shape 与 dtype 变化
  - 所处于推理中的阶段

硬约束：

- 不得仅靠单个 kernel 或算子名称对齐代码
- 不得因为映射不确定就隐藏 kernel 行，应保留并在必要时标记为 `insufficient_evidence`

### 9. kernel 代码映射表生成

核心目标：

- 最终报告必须以表格为中心
- 重点是 kernel -> code 的映射

主表必须按 kernel row：

- 每个 kernel row 对应一行
- 以具体 `row_id` 为键
- 不因共享 kernel 名、算子家族或粗 profiling 标签而合并多行
- 能通过 `row_id` 无歧义回连到切片后的 kernel csv
- 对 model-forward 行尽可能保留到 layer / substage 粒度

重复层折叠规则：

- 这里只允许对“重复层实例是否整体展示”做折叠，不允许对“已保留层内部的 kernel 行”做任何折叠或合并
- 也就是说：
  - 可以决定哪些重复层实例保留、哪些重复层实例不在最终表中展开
  - 但只要某一层实例被保留，该层里的每个 kernel 都必须逐行保留
  - 表格中的每一行仍然只能对应一个 kernel `row_id`
  - 非计算部分不得借此规则省略

始终要求：

- 主计算部分（decode forward，或开启投机推理时的 verify forward）
  - 第一层重复层必须完整保留，不能只用一句话概括
  - 最后一层重复层必须完整保留，不能只用一句话概括
  - 如果模型中存在不同类型的层，则每种类型至少完整保留一个代表层
  - 除以上保留层外，其他重复 layer 可以不在最终表中展开
  - 但凡被保留的层，其内部所有 kernel 都必须完整保留，不得省略，不得合并，不得把多个 kernel 写成一个汇总行
  - 被保留的计算层中的每个 kernel，仍然必须满足一行对应一个 kernel `row_id`
  - 被保留的计算层中的 kernel 名称后，需要明确标注其所属层号或层角色
- 投机推理中的 `draft_extend` / `draft_decode` forward 计算部分
  - `draft_extend` forward 必须完整保留
  - 若存在多个 `draft_decode`，只需完整保留一个代表性的 `draft_decode` forward
  - 但被保留的这个 `draft_decode` 内部所有 kernel 仍然必须完整保留，不得省略，不得合并
  - 被保留的 `draft_decode` 相关 kernel 需要明确标注属于第几个 `draft_decode`
- 所有非主计算部分都不得折叠或省略，包括但不限于调度、prepare、graph update、runtime-control、copy、sync、metadata 等相关 kernel 行；这些部分必须对所选窗口逐行完整保留

硬约束：

- 表格不得在一行合并多个 kernel `row_id`

### 10. review 生成的表格是否符合要求

review 内容：

- 检查主表是否保持逐 kernel、逐 `row_id`
- 检查保留层是否层内完整
- 检查非主计算部分是否逐行完整保留
- 检查映射到的代码是否能够索引到代码路径下具体文件的某几行

### 11. 轻量性能分析

原则：

- 只允许保留 trace + kernel 信息中明显能看出的影响性能的问题，严禁扩展为宽泛诊断清单

可保留的问题示例：

- 实际执行时没有走代码语义中可能期望开启的融合算子
- 实际执行时让代码语义中可能期望并行执行的部分串行
- 此模型结构的 forward 过程中存在处于同一时间段且没有数据依赖的部分，可多 stream 并行执行
- 计算部分明显耗时偏长的瓶颈算子

### 12. 报告生成

最终交付物是一份 Markdown 报告：

- 推荐文件名：`kernel_code_mapping_report_<case_name>.md`
- 报告语言：中文
- 报告格式：Markdown
- 所有面向人的章节标题、表标题、列标题、备注、摘要与 follow-up 项都必须用中文
- kernel 名称、算子名称、代码符号与文件路径可保留原语言
- 报告核心是 kernel 到代码映射表
- 每个必需映射表都必须在报告中渲染为 Markdown 表格
- 表格在严格保持完整性的基础上注意可读性，例如把包含很多 kernel 的一张大表按照大的计算阶段分成 verify forward、verify 到 draft extend 之间的调度 / prepare、draft_extend forward、draft_extend 到 draft_decode 之间的调度 / prepare、draft_decode forward、draft_decode 到 verify 之间的调度 / prepare。每个阶段的分表包含自己这一部分的 kernel。各个分表合在一起必须覆盖完整的 kernel
- 当要求中文时，不得输出英文主导报告
- 映射表必须是 Markdown 表格，不能是 CSV

总体注意事项：

- 重点是 kernel -> code 的映射，仅保留直接帮助映射的轻量性能说明
  - 注意该 skill 不以宽泛问题清单、完整 host 侧诊断或完整 TPOT 优先级分析

## 触发指引

当用户询问以下问题时触发该 skill：

- 某个 profiling 窗口对应哪些代码行
- 某个 kernel 或 kernel 序列对应哪些代码行
- Ascend 上 SGLang 的 profiling 到代码对齐
- 如何把 bubble 边界回映到代码切换点
- 如何生成逐 kernel 的代码映射表
