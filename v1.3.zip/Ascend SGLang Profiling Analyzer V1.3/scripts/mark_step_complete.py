from __future__ import annotations

import argparse
from pathlib import Path

from workflow_common import (
    STEP_DEFINITIONS,
    document_hashes,
    load_state,
    now_iso,
    parse_bool,
    required_step,
    save_state,
    split_assignment,
)


REQUIRED_DOCS = {
    1: ["task_plan.md", "findings.md", "progress.md"],
    2: ["findings.md", "progress.md"],
    3: ["findings.md", "progress.md"],
    4: ["findings.md", "progress.md"],
    5: ["findings.md", "progress.md"],
    6: ["findings.md", "progress.md"],
    7: ["findings.md", "progress.md"],
    8: ["task_plan.md", "findings.md", "progress.md"],
}


REQUIRED_FLAGS = {
    1: ["input_contract_valid"],
    2: ["raw_profiling_discovered", "preprocessing_done"],
    3: ["launch_context_checked", "model_context_checked"],
    4: ["token_path_reconstructed", "runtime_path_reconstructed"],
    5: ["structure_synthesized"],
    6: ["owner_competition_done"],
    7: ["alignment_done", "main_table_generated"],
    8: ["report_generated"],
}


REQUIRED_ARTIFACTS = {
    1: [],
    2: [
        "raw_trace_path",
        "raw_kernel_csv_path",
        "trace_slice_path",
        "trace_summary_path",
        "kernel_slice_path",
        "kernel_summary_path",
    ],
    3: [],
    4: ["token_path_summary_path"],
    5: [],
    6: ["owner_competition_path"],
    7: ["main_mapping_table_path"],
    8: ["final_report_path"],
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="校验 step 是否完成并推进状态机")
    parser.add_argument("--workspace-dir", required=True, help="工作区目录")
    parser.add_argument("--step", required=True, type=int, help="当前完成的 step")
    parser.add_argument(
        "--set-flag",
        action="append",
        default=[],
        help="设置状态 flag 格式为 key=true/false 可重复传入",
    )
    parser.add_argument(
        "--set-artifact",
        action="append",
        default=[],
        help="设置产物路径，格式为 key=path 可重复传入",
    )
    parser.add_argument("--next-action", help="覆盖默认下一动作")
    return parser


def apply_flag_updates(state: dict, assignments: list[str]) -> None:
    flags = state.setdefault("flags", {})
    for assignment in assignments:
        key, raw_value = split_assignment(assignment)
        if key not in flags:
            raise SystemExit(f"未知 flag: {key}")
        flags[key] = parse_bool(raw_value)


def apply_artifact_updates(state: dict, assignments: list[str]) -> None:
    artifacts = state.setdefault("artifacts", {})
    for assignment in assignments:
        key, raw_path = split_assignment(assignment)
        if key not in artifacts:
            raise SystemExit(f"未知 artifact: {key}")
        path = Path(raw_path).expanduser().resolve()
        if not path.exists():
            raise SystemExit(f"产物路径不存在: {path}")
        artifacts[key] = str(path)


def ensure_required_docs_changed(workspace_dir: Path, state: dict, step: int) -> list[str]:
    baseline = state.get("document_hashes_baseline", {})
    current = document_hashes(workspace_dir)
    errors = []
    for name in REQUIRED_DOCS[step]:
        if current.get(name) == baseline.get(name):
            errors.append(f"要求更新的文档未发生变化: {name}")
    return errors


def ensure_required_flags(state: dict, step: int) -> list[str]:
    flags = state.get("flags", {})
    return [f"缺少完成标记: {flag}" for flag in REQUIRED_FLAGS[step] if not flags.get(flag, False)]


def ensure_required_artifacts(state: dict, step: int) -> list[str]:
    artifacts = state.get("artifacts", {})
    errors = []
    for key in REQUIRED_ARTIFACTS[step]:
        raw_path = artifacts.get(key)
        if not raw_path:
            errors.append(f"缺少必需产物路径: {key}")
            continue

        artifact_path = Path(raw_path).expanduser()
        if not artifact_path.exists():
            errors.append(f"必需产物不存在: {key} -> {artifact_path}")
            continue

        if artifact_path.is_dir():
            errors.append(f"必需产物应为文件而不是目录: {key} -> {artifact_path}")
    return errors


def main() -> int:
    args = build_parser().parse_args()
    step = args.step
    required_step(step)

    workspace_dir = Path(args.workspace_dir).expanduser().resolve()
    state = load_state(workspace_dir)

    if state.get("current_step") != step:
        raise SystemExit(f"当前 step 为 {state.get('current_step')}，不能完成 step {step}")

    apply_flag_updates(state, args.set_flag)
    apply_artifact_updates(state, args.set_artifact)

    errors = []
    errors.extend(ensure_required_docs_changed(workspace_dir, state, step))
    errors.extend(ensure_required_flags(state, step))
    errors.extend(ensure_required_artifacts(state, step))

    if step == 8 and not state.get("artifacts", {}).get("final_report_path"):
        errors.append("缺少最终报告路径: final_report_path")

    if errors:
        state["status"] = "blocked"
        state["next_action"] = f"fix_step_{step}_completion"
        save_state(workspace_dir, state)
        print(f"Step {step} {STEP_DEFINITIONS[step]} 完成推进失败:")
        for item in errors:
            print(f"- {item}")
        return 1

    state["last_completed_step"] = step
    state.setdefault("step_history", []).append(
        {
            "step": step,
            "name": STEP_DEFINITIONS[step],
            "status": "completed",
            "at": now_iso(),
        }
    )

    if step < 8:
        state["current_step"] = step + 1
        state["status"] = "in_progress"
        state["next_action"] = args.next_action or f"run_step_{step + 1}"
    else:
        state["status"] = "awaiting_final_gate"
        state["next_action"] = args.next_action or "run_final_gate"

    state["document_hashes_baseline"] = document_hashes(workspace_dir)
    save_state(workspace_dir, state)

    print(f"Step {step} {STEP_DEFINITIONS[step]} 已完成")
    print(f"下一动作: {state['next_action']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
