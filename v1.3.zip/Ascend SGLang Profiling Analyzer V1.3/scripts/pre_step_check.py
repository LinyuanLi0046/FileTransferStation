from __future__ import annotations

import argparse
from pathlib import Path

from workflow_common import STEP_DEFINITIONS, load_state, required_step, save_state


PREREQUISITES = {
    1: [],
    2: ["input_contract_valid"],
    3: ["raw_profiling_discovered", "preprocessing_done"],
    4: ["launch_context_checked", "model_context_checked"],
    5: ["token_path_reconstructed", "runtime_path_reconstructed"],
    6: ["structure_synthesized"],
    7: ["owner_competition_done"],
    8: ["alignment_done", "main_table_generated"],
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="检查指定 step 是否允许开始")
    parser.add_argument("--workspace-dir", required=True, help="工作区目录")
    parser.add_argument("--step", required=True, type=int, help="目标 step 编号")
    return parser


def ensure_current_step_matches(state: dict, step: int) -> list[str]:
    errors = []
    current_step = state.get("current_step")
    if current_step != step:
        errors.append(f"当前状态机 step 为 {current_step}，不能直接进入 step {step}")
    if state.get("status") == "completed":
        errors.append("任务已完成，不能再进入新 step")
    return errors


def ensure_prerequisites(state: dict, step: int) -> list[str]:
    flags = state.get("flags", {})
    return [f"前置条件未满足: {flag}" for flag in PREREQUISITES[step] if not flags.get(flag, False)]


def ensure_input_contract_for_step_one(state: dict) -> list[str]:
    errors = []
    inputs = state.get("inputs", {})
    required_inputs = {
        "profiling_root_path": "profiling 根路径",
        "window_start_ns": "window_start_ns",
        "window_end_ns": "window_end_ns",
        "model_weight_path": "模型权重路径",
        "code_repo_path": "本地代码仓路径",
        "launch_command": "启动命令/脚本",
    }
    for key, label in required_inputs.items():
        if not inputs.get(key):
            errors.append(f"缺少输入: {label}")

    profiling_root_raw = inputs.get("profiling_root_path")
    model_weight_raw = inputs.get("model_weight_path")
    code_repo_raw = inputs.get("code_repo_path")
    window_start_raw = inputs.get("window_start_ns")
    window_end_raw = inputs.get("window_end_ns")

    if profiling_root_raw:
        profiling_root = Path(profiling_root_raw).expanduser()
        if not profiling_root.exists():
            errors.append(f"profiling 根路径不存在: {profiling_root}")
        elif not profiling_root.is_dir():
            errors.append(f"profiling 根路径不是目录: {profiling_root}")
        else:
            if profiling_root.name == "ASCEND_PROFILER_OUTPUT":
                errors.append("profiling 输入必须是 profiling 根路径，不能直接传入 ASCEND_PROFILER_OUTPUT 目录")
            if profiling_root.name in {"trace_view.json", "kernel_details.csv"}:
                errors.append("profiling 输入必须是 profiling 根路径，不能直接传入原始文件路径")

            profiler_output_dir = profiling_root / "ASCEND_PROFILER_OUTPUT"
            if not profiler_output_dir.exists() or not profiler_output_dir.is_dir():
                errors.append(f"profiling 根路径下缺少 ASCEND_PROFILER_OUTPUT 目录: {profiler_output_dir}")
            else:
                trace_path = profiler_output_dir / "trace_view.json"
                kernel_csv_path = profiler_output_dir / "kernel_details.csv"
                if not trace_path.exists() or not trace_path.is_file():
                    errors.append(f"缺少原始 trace_view.json: {trace_path}")
                if not kernel_csv_path.exists() or not kernel_csv_path.is_file():
                    errors.append(f"缺少原始 kernel_details.csv: {kernel_csv_path}")

    if model_weight_raw:
        model_weight_path = Path(model_weight_raw).expanduser()
        if not model_weight_path.exists():
            errors.append(f"模型权重路径不存在: {model_weight_path}")

    if code_repo_raw:
        code_repo_path = Path(code_repo_raw).expanduser()
        if not code_repo_path.exists():
            errors.append(f"本地代码仓路径不存在: {code_repo_path}")
        elif not code_repo_path.is_dir():
            errors.append(f"本地代码仓路径不是目录: {code_repo_path}")

    if window_start_raw and window_end_raw:
        try:
            window_start = int(str(window_start_raw))
            window_end = int(str(window_end_raw))
            if window_end <= window_start:
                errors.append(
                    f"时间窗口非法: window_end_ns({window_end}) 必须大于 window_start_ns({window_start})"
                )
        except ValueError:
            errors.append("时间窗口非法: window_start_ns 和 window_end_ns 必须是整数")

    return errors


def ensure_artifacts_for_step(state: dict, step: int) -> list[str]:
    artifacts = state.get("artifacts", {})
    errors = []
    if step == 3:
        for key in ("raw_trace_path", "raw_kernel_csv_path", "trace_summary_path", "kernel_summary_path"):
            if not artifacts.get(key):
                errors.append(f"缺少预处理产物路径: {key}")
    if step == 5 and not artifacts.get("token_path_summary_path"):
        errors.append("缺少 token 路径摘要产物: token_path_summary_path")
    if step == 7 and not artifacts.get("owner_competition_path"):
        errors.append("缺少 owner 竞争产物: owner_competition_path")
    return errors


def main() -> int:
    args = build_parser().parse_args()
    step = args.step
    required_step(step)

    workspace_dir = Path(args.workspace_dir).expanduser().resolve()
    state = load_state(workspace_dir)

    errors = []
    errors.extend(ensure_current_step_matches(state, step))
    errors.extend(ensure_prerequisites(state, step))

    if step == 1:
        errors.extend(ensure_input_contract_for_step_one(state))
    else:
        errors.extend(ensure_artifacts_for_step(state, step))

    if errors:
        state["status"] = "blocked"
        state["next_action"] = f"fix_pre_step_check_for_step_{step}"
        save_state(workspace_dir, state)
        print(f"Step {step} {STEP_DEFINITIONS[step]} 门禁失败:")
        for item in errors:
            print(f"- {item}")
        return 1

    state["status"] = "in_progress"
    state["next_action"] = f"execute_step_{step}"
    save_state(workspace_dir, state)
    print(f"Step {step} {STEP_DEFINITIONS[step]} 门禁通过")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
