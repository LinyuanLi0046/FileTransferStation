from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


STEP_DEFINITIONS = {
    1: "输入契约校验",
    2: "原始 profiling 发现与固定预处理",
    3: "启动参数与模型结构检查",
    4: "单 token 路径重建",
    5: "kernel 设备侧分析与结构综合",
    6: "通用小 kernel owner 竞争分析",
    7: "profiling 到代码对齐与主表生成",
    8: "最终 review 与报告生成",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, content: str) -> None:
    ensure_parent(path)
    path.write_text(content, encoding="utf-8", newline="\n")


def compute_sha256(path: Path) -> str:
    if not path.exists():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def dump_json(path: Path, payload: dict[str, Any]) -> None:
    ensure_parent(path)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def load_state(workspace_dir: Path) -> dict[str, Any]:
    state_path = workspace_dir / "state.json"
    if not state_path.exists():
        raise FileNotFoundError(f"缺少状态文件: {state_path}")
    return load_json(state_path)


def save_state(workspace_dir: Path, state: dict[str, Any]) -> None:
    state["updated_at"] = now_iso()
    dump_json(workspace_dir / "state.json", state)


def document_hashes(workspace_dir: Path) -> dict[str, str]:
    return {
        "task_plan.md": compute_sha256(workspace_dir / "task_plan.md"),
        "findings.md": compute_sha256(workspace_dir / "findings.md"),
        "progress.md": compute_sha256(workspace_dir / "progress.md"),
    }


def parse_bool(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"1", "true", "yes", "y"}:
        return True
    if normalized in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"无法解析布尔值: {value}")


def split_assignment(value: str) -> tuple[str, str]:
    if "=" not in value:
        raise ValueError(f"参数必须形如 key=value: {value}")
    key, raw_value = value.split("=", 1)
    key = key.strip()
    if not key:
        raise ValueError(f"参数键不能为空: {value}")
    return key, raw_value.strip()


def required_step(step: int) -> str:
    if step not in STEP_DEFINITIONS:
        raise ValueError(f"不支持的 step: {step}")
    return STEP_DEFINITIONS[step]
