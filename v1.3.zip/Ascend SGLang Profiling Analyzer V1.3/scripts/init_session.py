from __future__ import annotations

import argparse
from pathlib import Path

from workflow_common import STEP_DEFINITIONS, document_hashes, dump_json, now_iso, write_text


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="初始化 Profiling Analyzer V1.3 工作区")
    parser.add_argument("--workspace-dir", required=True, help="工作区目录")
    parser.add_argument("--task-id", help="任务 id 默认使用工作区目录名")
    parser.add_argument("--profiling-root-path", help="profiling 根路径")
    parser.add_argument("--window-start-ns", help="窗口起始时间戳")
    parser.add_argument("--window-end-ns", help="窗口终止时间戳")
    parser.add_argument("--model-weight-path", help="模型权重路径")
    parser.add_argument("--code-repo-path", help="代码仓路径")
    parser.add_argument("--launch-command", help="启动命令或脚本")
    parser.add_argument("--benchmark-command", help="benchmark 命令")
    parser.add_argument("--benchmark-result-path", help="benchmark 结果路径")
    parser.add_argument("--force", action="store_true", help="允许覆盖已存在的状态文件")
    return parser


def task_plan_template(task_id: str) -> str:
    lines = [
        f"# Task Plan - {task_id}",
        "",
        "## 当前状态",
        "",
        "- 当前 step：1 输入契约校验",
        "- 上一完成 step：无",
        "- 下一动作：运行 `scripts/pre_step_check.py --step 1` 并开始输入契约校验",
        "",
        "## Step 清单",
        "",
    ]
    for step, name in STEP_DEFINITIONS.items():
        status = "in_progress" if step == 1 else "pending"
        lines.append(f"- Step {step}: {name} [{status}]")
    lines.extend(
        [
            "",
            "## 关键决策",
            "",
            "- 待填写",
            "",
        ]
    )
    return "\n".join(lines)


def findings_template() -> str:
    return "\n".join(
        [
            "# Findings",
            "",
            "## 输入契约发现",
            "",
            "- 待填写",
            "",
            "## 启动参数与模型结构发现",
            "",
            "- 待填写",
            "",
            "## Token 路径发现",
            "",
            "- 待填写",
            "",
            "## Runtime 路径发现",
            "",
            "- 待填写",
            "",
            "## Owner 竞争发现",
            "",
            "- 待填写",
            "",
            "## Mapping 关键证据",
            "",
            "- 待填写",
            "",
            "## Coverage 与未解析结论",
            "",
            "- 待填写",
            "",
        ]
    )


def progress_template() -> str:
    return "\n".join(
        [
            "# Progress",
            "",
            "## 执行记录",
            "",
            f"- {now_iso()} 初始化工作区",
            "",
            "## 门禁结果",
            "",
            "- 待填写",
            "",
        ]
    )


def build_state(workspace_dir: Path, args: argparse.Namespace) -> dict:
    task_id = args.task_id or workspace_dir.name
    return {
        "schema": "profiling_analyzer_state/v1",
        "task_id": task_id,
        "workspace_dir": str(workspace_dir),
        "status": "initialized",
        "current_step": 1,
        "last_completed_step": 0,
        "next_action": "run_step_1",
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "inputs": {
            "profiling_root_path": args.profiling_root_path,
            "window_start_ns": args.window_start_ns,
            "window_end_ns": args.window_end_ns,
            "model_weight_path": args.model_weight_path,
            "code_repo_path": args.code_repo_path,
            "launch_command": args.launch_command,
            "benchmark_command": args.benchmark_command,
            "benchmark_result_path": args.benchmark_result_path,
        },
        "flags": {
            "input_contract_valid": False,
            "raw_profiling_discovered": False,
            "preprocessing_done": False,
            "launch_context_checked": False,
            "model_context_checked": False,
            "token_path_reconstructed": False,
            "runtime_path_reconstructed": False,
            "structure_synthesized": False,
            "owner_competition_done": False,
            "alignment_done": False,
            "main_table_generated": False,
            "report_generated": False,
            "final_review_passed": False,
            "has_unresolved_rows": False,
            "folding_used": False,
            "runtime_subphases_required": False,
            "last_layer_table_required": False,
        },
        "artifacts": {
            "raw_trace_path": "",
            "raw_kernel_csv_path": "",
            "trace_slice_path": "",
            "trace_summary_path": "",
            "kernel_slice_path": "",
            "kernel_summary_path": "",
            "token_path_summary_path": "",
            "owner_competition_path": "",
            "main_mapping_table_path": "",
            "final_report_path": "",
        },
        "document_hashes_baseline": {},
        "step_history": [
            {
                "step": 0,
                "name": "初始化会话工作区",
                "status": "completed",
                "at": now_iso(),
            }
        ],
    }


def main() -> int:
    args = build_parser().parse_args()
    workspace_dir = Path(args.workspace_dir).expanduser().resolve()

    if (workspace_dir / "state.json").exists() and not args.force:
        raise SystemExit("工作区已存在 state.json，如需覆盖请加 --force")

    workspace_dir.mkdir(parents=True, exist_ok=True)
    for name in ("input", "artifacts", "output", "logs", "audit"):
        (workspace_dir / name).mkdir(parents=True, exist_ok=True)

    state = build_state(workspace_dir, args)
    write_text(workspace_dir / "task_plan.md", task_plan_template(state["task_id"]))
    write_text(workspace_dir / "findings.md", findings_template())
    write_text(workspace_dir / "progress.md", progress_template())
    state["document_hashes_baseline"] = document_hashes(workspace_dir)
    dump_json(workspace_dir / "state.json", state)

    print(f"初始化完成: {workspace_dir}")
    print("下一步: 运行 scripts/pre_step_check.py --step 1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
