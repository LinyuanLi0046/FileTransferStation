from __future__ import annotations

import argparse
from pathlib import Path

from workflow_common import load_state, now_iso, read_text, save_state


REQUIRED_HEADINGS = [
    "配置上下文",
    "token 路径摘要",
    "覆盖摘要",
    "轻量性能说明",
    "后续输入",
]

REQUIRED_COVERAGE_FIELDS = [
    "Selected window row count",
    "Main compute total row count",
    "Main compute displayed layer instances",
    "Main compute folded layer instances",
    "Non-main-compute total row count",
    "Non-main-compute displayed row count",
    "Insufficient-evidence row count",
    "Coverage reconciliation note",
]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="检查最终报告是否满足输出契约最低门禁")
    parser.add_argument("--workspace-dir", required=True, help="工作区目录")
    parser.add_argument("--report-path", help="最终报告路径，默认读取 state.json 中的 final_report_path")
    return parser


def contains_heading(markdown: str, heading: str) -> bool:
    candidates = [f"# {heading}", f"## {heading}", f"### {heading}", f"#### {heading}"]
    return any(candidate in markdown for candidate in candidates)


def contains_main_table_title(markdown: str) -> bool:
    return (
        "主 Kernel Row 到代码映射表" in markdown
        or "Primary Kernel-to-Code Mapping Table" in markdown
    )


def contains_last_layer_title(markdown: str) -> bool:
    return (
        "最后一层计算 Kernel Row 到代码映射表" in markdown
        or "Last-Layer Compute Row Mapping Table" in markdown
    )


def main() -> int:
    args = build_parser().parse_args()
    workspace_dir = Path(args.workspace_dir).expanduser().resolve()
    state = load_state(workspace_dir)

    report_path_str = args.report_path or state.get("artifacts", {}).get("final_report_path", "")
    if not report_path_str:
        raise SystemExit("缺少最终报告路径，请通过 --report-path 或 state.json.artifacts.final_report_path 提供")

    report_path = Path(report_path_str).expanduser().resolve()
    if not report_path.exists():
        raise SystemExit(f"最终报告不存在: {report_path}")

    markdown = read_text(report_path)
    flags = state.get("flags", {})
    errors = []

    for heading in REQUIRED_HEADINGS:
        if not contains_heading(markdown, heading):
            errors.append(f"缺少章节标题: {heading}")

    if not contains_main_table_title(markdown):
        errors.append("缺少主 Kernel Row 到代码映射表标题")

    for field in REQUIRED_COVERAGE_FIELDS:
        if field not in markdown:
            errors.append(f"缺少 coverage 字段: {field}")

    if flags.get("runtime_subphases_required") and not contains_heading(markdown, "运行时子阶段摘要"):
        errors.append("state 要求运行时子阶段摘要，但报告中缺失该章节")

    if flags.get("folding_used") and not contains_heading(markdown, "重复层折叠说明"):
        errors.append("state 要求重复层折叠说明，但报告中缺失该章节")

    if flags.get("has_unresolved_rows") and not contains_heading(markdown, "未解析行"):
        errors.append("state 标记存在 unresolved rows，但报告中缺失该章节")

    if flags.get("last_layer_table_required") and not contains_last_layer_title(markdown):
        errors.append("state 要求最后一层计算表，但报告中缺失该表标题")

    if errors:
        state["status"] = "blocked"
        state["next_action"] = "fix_final_report_and_retry_final_gate"
        save_state(workspace_dir, state)
        print("最终门禁失败:")
        for item in errors:
            print(f"- {item}")
        return 1

    flags["final_review_passed"] = True
    state["status"] = "completed"
    state["next_action"] = "completed"
    state.setdefault("step_history", []).append(
        {
            "step": "final_gate",
            "name": "最终门禁",
            "status": "completed",
            "at": now_iso(),
        }
    )
    save_state(workspace_dir, state)
    print(f"最终门禁通过: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
