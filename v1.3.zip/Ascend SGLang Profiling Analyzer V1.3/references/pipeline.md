# 流水线与状态机

该文件定义 V1.3 的最小可用状态机、阶段顺序、阶段输入输出、完成标准与脚本门禁。

- [SKILL.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/SKILL.md) 负责说明“怎么分析”
- [output_contract.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/references/output_contract.md) 负责说明“最后必须交出什么”
- 本文件负责说明“当前在第几步、下一步是什么、怎样才算完成、如何被脚本阻断”

## 1. 工作区

每次任务都必须先创建一个独立工作区。工作区至少包含：

- `state.json`
- `task_plan.md`
- `findings.md`
- `progress.md`
- `input/`
- `artifacts/`
- `output/`
- `logs/`
- `audit/`

这些文件和目录由 `scripts/init_session.py` 初始化。

## 2. 状态机总览

```text
STEP 0  INIT_SESSION
  -> STEP 1  INPUT_CONTRACT_VALIDATION
  -> STEP 2  RAW_PROFILING_DISCOVERY_AND_FIXED_PREPROCESSING
  -> STEP 3  LAUNCH_AND_MODEL_CONTEXT_CHECK
  -> STEP 4  TOKEN_PATH_RECONSTRUCTION
  -> STEP 5  KERNEL_DEVICE_ANALYSIS_AND_STRUCTURE_SYNTHESIS
  -> STEP 6  GENERIC_CLUSTER_OWNER_COMPETITION
  -> STEP 7  PROFILING_TO_CODE_ALIGNMENT_AND_MAIN_TABLE
  -> STEP 8  FINAL_REVIEW_AND_REPORT_RENDER
  -> FINAL GATE  REPORT_CONTRACT_VALIDATION
```

状态推进规则：

- 每个 step 开始前必须运行 `scripts/pre_step_check.py`
- 每个 step 完成后必须运行 `scripts/mark_step_complete.py`
- 最终报告完成后必须运行 `scripts/check_final_gate.py`
- 任一门禁失败都必须先修正问题，再重试，不得跳过

## 3. `state.json` 最小字段

`state.json` 至少应维护以下信息：

- `schema`
- `task_id`
- `workspace_dir`
- `status`
- `current_step`
- `last_completed_step`
- `next_action`
- `created_at`
- `updated_at`
- `inputs`
- `flags`
- `artifacts`
- `document_hashes_baseline`
- `step_history`

### 3.1 `status` 取值

- `initialized`
- `in_progress`
- `awaiting_final_gate`
- `completed`
- `blocked`

### 3.2 `flags` 最小集合

- `input_contract_valid`
- `raw_profiling_discovered`
- `preprocessing_done`
- `launch_context_checked`
- `model_context_checked`
- `token_path_reconstructed`
- `runtime_path_reconstructed`
- `structure_synthesized`
- `owner_competition_done`
- `alignment_done`
- `main_table_generated`
- `report_generated`
- `final_review_passed`
- `has_unresolved_rows`
- `folding_used`
- `runtime_subphases_required`
- `last_layer_table_required`

### 3.3 `artifacts` 最小集合

- `raw_trace_path`
- `raw_kernel_csv_path`
- `trace_slice_path`
- `trace_summary_path`
- `kernel_slice_path`
- `kernel_summary_path`
- `token_path_summary_path`
- `owner_competition_path`
- `main_mapping_table_path`
- `final_report_path`

## 4. 状态文件职责

- `state.json`：机器可读状态与门禁依据
- `task_plan.md`：当前 step、完成情况、下一步安排
- `findings.md`：关键证据、判断结论、路径重建结果、owner 竞争结果、映射依据
- `progress.md`：实际执行记录、失败原因、门禁检查结果、修复动作

## 5. Step 细节

### Step 0. 初始化会话工作区

脚本：

- `scripts/init_session.py`

输入：

- 任务工作区路径
- 可选的任务 id
- 可选的初始输入参数

输出：

- 已创建的工作区目录结构
- 已初始化的 `state.json`
- 已初始化的 `task_plan.md`
- 已初始化的 `findings.md`
- 已初始化的 `progress.md`

完成标准：

- 四个核心状态文件均存在
- 工作区目录结构完整
- `state.json.current_step = 1`
- `state.json.status = initialized`

### Step 1. 输入契约校验

前置门禁：

- `scripts/pre_step_check.py --step 1`

输入：

- profiling 根路径
- `window_start_ns`
- `window_end_ns`
- 模型权重路径
- 本地代码仓路径
- 启动命令 / 脚本
- 可选 benchmark 命令 / 结果

工作：

- 验证必需输入是否存在
- 验证 profiling 输入是 profiling 根路径，而不是切片或派生工件
- 验证时间窗口存在且有序
- 记录输入契约摘要与缺失项

完成标准：

- `flags.input_contract_valid = true`
- `findings.md` 已写入输入契约检查结果
- `progress.md` 已记录本 step 的执行结论

阶段完成：

- `scripts/mark_step_complete.py --step 1`

### Step 2. 原始 profiling 发现与固定预处理

前置门禁：

- `scripts/pre_step_check.py --step 2`

输入：

- profiling 根路径
- 已接受的 token 窗口

工作：

- 在 `ASCEND_PROFILER_OUTPUT` 下发现原始 `trace_view.json`
- 在 `ASCEND_PROFILER_OUTPUT` 下发现原始 `kernel_details.csv`
- 严格按固定顺序运行 4 个预处理脚本
- 记录原始证据路径与派生工件路径

完成标准：

- `flags.raw_profiling_discovered = true`
- `flags.preprocessing_done = true`
- `artifacts.raw_trace_path` 已填写
- `artifacts.raw_kernel_csv_path` 已填写
- `artifacts.trace_slice_path`、`artifacts.trace_summary_path`、`artifacts.kernel_slice_path`、`artifacts.kernel_summary_path` 已填写
- `findings.md` 与 `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 2`

### Step 3. 启动参数与模型结构检查

前置门禁：

- `scripts/pre_step_check.py --step 3`

输入：

- 启动命令 / 脚本
- `config.json`
- 可选 `quant_model_description.json`

工作：

- 检查真实启动参数
- 检查模型 architecture、重复层模式、量化方式与 MoE 特征
- 记录理论执行路径所需的模型侧约束

完成标准：

- `flags.launch_context_checked = true`
- `flags.model_context_checked = true`
- `findings.md` 已写入启动参数与模型结构摘要
- `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 3`

### Step 4. 单 token 路径重建

前置门禁：

- `scripts/pre_step_check.py --step 4`

输入：

- 启动参数
- 模型结构上下文
- 预处理工件
- 代码仓

工作：

- 重建 model forward 路径
- 重建 runtime-control / 调度 / graph 路径
- 对需要的场景检查运行时子阶段

完成标准：

- `flags.token_path_reconstructed = true`
- `flags.runtime_path_reconstructed = true`
- 若适用，`flags.runtime_subphases_required` 已正确设置
- `artifacts.token_path_summary_path` 已填写
- `findings.md` 与 `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 4`

### Step 5. kernel 设备侧分析与结构综合

前置门禁：

- `scripts/pre_step_check.py --step 5`

输入：

- trace 汇总工件
- kernel 汇总工件
- token 路径摘要

工作：

- 分析窗口内 kernel 设备侧执行情况
- 综合 trace 结构与 kernel 结构
- 识别 layer 边界、重复层模式、output-head anchor 与 runtime 邻域

完成标准：

- `flags.structure_synthesized = true`
- `findings.md` 已写入设备侧分析与结构综合结果
- `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 5`

### Step 6. 通用小 kernel owner 竞争分析

前置门禁：

- `scripts/pre_step_check.py --step 6`

输入：

- 结构综合结果
- token 路径摘要
- 运行时路径摘要

工作：

- 对通用小 kernel 簇进行 owner 竞争
- 在需要时显式检查 `runtime_future_resolve`
- 对无法严格归属的簇做拆分或诚实降级

完成标准：

- `flags.owner_competition_done = true`
- `artifacts.owner_competition_path` 已填写
- `findings.md` 已写入 owner 竞争结果
- `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 6`

### Step 7. profiling 到代码对齐与主表生成

前置门禁：

- `scripts/pre_step_check.py --step 7`

输入：

- owner 竞争结果
- 预处理工件
- 代码仓

工作：

- 进行 profiling 到代码严格对齐
- 生成主 Kernel Row 到代码映射表
- 根据规则处理重复层折叠与非主计算部分完整保留
- 标记 `insufficient_evidence`

完成标准：

- `flags.alignment_done = true`
- `flags.main_table_generated = true`
- 若有折叠，`flags.folding_used` 已正确设置
- 若有 unresolved rows，`flags.has_unresolved_rows` 已正确设置
- 若需要最后一层专表，`flags.last_layer_table_required` 已正确设置
- `artifacts.main_mapping_table_path` 已填写
- `findings.md` 与 `progress.md` 已更新

阶段完成：

- `scripts/mark_step_complete.py --step 7`

### Step 8. 最终 review 与报告生成

前置门禁：

- `scripts/pre_step_check.py --step 8`

输入：

- 主映射表
- coverage 对账结果
- 必要时的运行时子阶段摘要
- 必要时的折叠说明
- 必要时的 unresolved rows

工作：

- 按输出契约组装最终报告
- 检查主表粒度、折叠策略与 coverage 对账
- 生成最终 Markdown 报告

完成标准：

- `flags.report_generated = true`
- `artifacts.final_report_path` 已填写
- `progress.md` 已记录报告生成结果
- `state.json.status = awaiting_final_gate`

阶段完成：

- `scripts/mark_step_complete.py --step 8`

## 6. 最终门禁

脚本：

- `scripts/check_final_gate.py`

检查目标：

- 最终报告文件存在
- 必要章节存在
- 主表标题存在
- coverage 对账字段存在
- 根据 `state.json.flags` 检查条件章节是否存在
- 通过后将 `flags.final_review_passed = true`
- 通过后将 `state.json.status = completed`

未通过时：

- 将 `state.json.status = blocked`
- `progress.md` 必须记录失败原因
- 修复后重新执行最终门禁

## 7. 推荐执行顺序

1. `scripts/init_session.py`
2. `scripts/pre_step_check.py --step 1`
3. 完成 Step 1 后执行 `scripts/mark_step_complete.py --step 1`
4. 依次对 Step 2 到 Step 8 重复“前置门禁 -> 执行分析 -> 完成推进”
5. 生成最终报告后执行 `scripts/check_final_gate.py`

## 8. 最小审计要求

最小可用状态机阶段至少要求：

- 所有 step 的推进都写入 `state.json.step_history`
- 每次 step 完成都更新 `task_plan.md`、`findings.md` 或 `progress.md`
- 失败的门禁检查必须写入 `progress.md`
- 所有关键产物路径都必须写入 `state.json.artifacts`
