# 输出契约与最终检查清单

该文件用于定义最终报告必须长什么样，以及交付前必须如何自检。
它与 [SKILL.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/SKILL.md) 保持一致：

- `SKILL.md` 负责“怎么做”
- 本文件负责“最后必须交出什么”和“如何检查是否合格”

## 1. 最终交付物

每次完整运行应生成一个主要输出：

- `kernel_code_mapping_report_<case_name>.md`

通用规则：

- 最终报告必须使用中文
- 最终报告必须以 Markdown 交付
- 所有面向人的章节标题、表标题、列标题、备注、摘要与后续项都必须用中文
- kernel 名称、算子名称、代码符号与文件路径可保留原语言
- 最终报告必须以 kernel 到代码映射表为中心
- 每个必需映射表都必须以 Markdown 表格形式出现在报告中
- CSV 只能作为预处理工件或可选机器可读附件，不能替代最终 Markdown 表格

## 2. 报告必须包含的章节

最终报告至少应包含：

- 配置上下文
- token 路径摘要
- 主 Kernel Row 到代码映射表
- 必要时的最后一层计算 Kernel Row 到代码映射表
- 覆盖摘要
- 必要时的运行时子阶段摘要
- 必要时的 buffer provenance 备注
- 使用重复层折叠时的说明
- 必要时的 unresolved rows
- 轻量性能说明
- 后续输入

### 2.1 配置上下文

至少应包含：

- profiling 根路径
- `ASCEND_PROFILER_OUTPUT` 路径
- 原始 `trace_view.json` 路径
- 原始 `kernel_details.csv` 路径
- `window_start_ns`
- `window_end_ns`
- 模型权重路径
- 本地代码仓路径
- 启动命令 / 脚本
- 可用证据
- 缺失前提 / 证据
- 是否允许严格代码定位

### 2.2 Token 路径摘要

该节只允许作为 phase 级摘要，不能替代逐行代码定位。

### 2.3 主 Kernel Row 到代码映射表

固定标题：

- `Primary Kernel-to-Code Mapping Table`
- `主 Kernel Row 到代码映射表`

推荐列：

- `Seq`
- `Kernel row id`
- `Kernel name`
- `Stream`
- `Time window`
- `Phase`
- `Layer ordinal / range`
- `Substage`
- `Owner class`
- `Mapped file`
- `Mapped function / region`
- `Mapped line / range`
- `Localization ceiling`
- `Match basis`
- `Refs`
- `Confidence`
- `Notes`

### 2.4 最后一层计算 Kernel Row 到代码映射表

当使用对照窗口或参考窗口来证明目标模型计算行为、双流证据或最后一层候选时，该节是强制的。

固定标题：

- `Last-Layer Compute Row Mapping Table`
- `最后一层计算 Kernel Row 到代码映射表`

### 2.5 覆盖摘要

必须显式给出：

- `Selected window row count`
- `Main compute total row count`
- `Main compute displayed layer instances`
- `Main compute folded layer instances`
- `Non-main-compute total row count`
- `Non-main-compute displayed row count`
- `Insufficient-evidence row count`
- `Coverage reconciliation note`

### 2.6 运行时子阶段摘要

对于 speculative、overlap 较重或 scheduler 驱动运行，该节是强制的。至少应覆盖：

- `runtime_future_resolve`
- `runtime_metadata_prepare`
- `target_verify_body`
- `verify_accept_or_sample`
- `tree_or_cache_update`
- `scheduler_postprocess_or_writeback`

### 2.7 重复层折叠说明

当主计算部分做层实例折叠时，该节是强制的。

至少应说明：

- 哪些层实例完整保留
- 哪些层实例未在最终表中展开
- 为什么这些层可以折叠
- 每种层类型保留了哪个代表层
- 第一层与最后一层是否完整保留
- `draft_extend` 与 `draft_decode` 的保留策略

### 2.8 未解析行

当存在未能定位到超出 `insufficient_evidence` 的行时，该节是强制的。

至少应包含：

- `Kernel row id or range`
- `Why unresolved`
- `Strongest honest owner`
- `Strongest honest code region`
- `Missing evidence`

## 3. 表格粒度要求

所有出现在最终报告中的 kernel 行，都必须满足：

- 一行只能对应一个 kernel `row_id`
- 不得因共享 kernel 名、算子家族、layer、substage 或粗 profiling 标签而合并多行
- 被展示的计算行不得合并
- 被展示的运行时行不得合并
- 若无法精确定位，应给出最窄且诚实的行号范围，或标记为 `insufficient_evidence`

## 4. 折叠与保留规则

### 4.1 主计算部分

主计算部分允许按层实例做折叠展示，但必须满足：

- 第一层重复层完整保留
- 最后一层重复层完整保留
- 如果模型中存在不同类型的层，则每种类型至少完整保留一个代表层
- 被保留层内部的所有 kernel 都必须完整保留
- 被保留层内部的 kernel 不得省略、不得合并、不得汇总成一行
- 被保留层中的每个 kernel 仍然必须一行对应一个 kernel `row_id`
- 被保留的计算层中的 kernel 名称后，需要明确标注所属层号或层角色

### 4.2 投机推理中的计算部分

- `draft_extend` forward 必须完整保留
- 若存在多个 `draft_decode`，只需完整保留一个代表性的 `draft_decode` forward
- 被保留的 `draft_decode` 内部所有 kernel 仍然必须完整保留
- 被保留的 `draft_decode` 相关 kernel 需要明确标注属于第几个 `draft_decode`

### 4.3 必须全量保留的行

所有非主计算部分都不得折叠或省略，包括但不限于：

- 调度相关 kernel 行
- prepare 相关 kernel 行
- graph update 相关 kernel 行
- runtime-control 相关 kernel 行
- copy / sync / metadata 等相关 kernel 行

这些部分必须对所选窗口逐行完整保留。

## 5. coverage 对账规则

coverage 对账必须显式区分“主计算部分”和“非主计算部分”。

必须做到：

- 说明所选窗口总 kernel 行数
- 说明主计算部分总行数
- 说明主计算部分哪些层实例被展示
- 说明主计算部分哪些层实例被折叠未展示
- 说明非主计算部分总行数
- 说明非主计算部分已展示行数
- 说明 `insufficient_evidence` 行数
- 用对账说明解释为什么最终报告仍覆盖了完整窗口语义

不允许：

- 只给出一个总行数而不解释折叠
- 把未展示的主计算层实例说成“已映射”
- 省略非主计算部分的 coverage 统计

## 6. 最终检查清单

交付前至少检查以下项目：

### 6.1 输入与预处理

- 是否使用了单一输入契约
- profiling 输入是否是 profiling 根路径，而不是切片或派生工件
- 是否存在 `window_start_ns` 与 `window_end_ns`
- 是否在 `ASCEND_PROFILER_OUTPUT` 下找到原始 `trace_view.json` 与 `kernel_details.csv`
- 是否按固定顺序执行了四个预处理脚本

### 6.2 路径重建与对齐

- 是否先重建代码路径再做 profiling 到代码对齐
- 是否同时分析了 model forward 与运行时控制 / 调度 / graph 路径
- 是否对通用小 kernel 做了 owner 竞争
- 是否在需要时显式检查了 `runtime_future_resolve`
- 是否没有仅凭单个 kernel 名称做归属

### 6.3 主表粒度

- 主表是否是 Markdown 表格
- 主表标题是否正确
- 表中每行是否只包含一个 kernel `row_id`
- 被展示的计算行是否完全没有合并
- 被展示的运行时行是否完全没有合并
- 主表是否仍可通过 `row_id` 回连到切片后的 kernel csv

### 6.4 折叠策略

- 是否只对主计算部分做“层实例级别”的折叠
- 是否没有对被保留层内部的 kernel 行做折叠
- 第一层重复层是否完整保留
- 最后一层重复层是否完整保留
- 每种不同类型的层是否至少保留一个代表层
- `draft_extend` 是否完整保留
- 若存在多个 `draft_decode`，是否完整保留了一个代表性 `draft_decode`
- 折叠说明是否写清保留层与折叠层

### 6.5 非主计算部分

- 调度、prepare、graph update、runtime-control、copy、sync、metadata 等相关 kernel 行是否全部逐行保留
- 是否不存在通过“折叠规则”间接省略非主计算部分的情况

### 6.6 报告完整性

- 是否包含必须章节
- 是否包含 coverage 对账
- 是否包含必要时的运行时子阶段摘要
- 是否包含必要时的 unresolved rows
- 是否只保留轻量性能说明
- 是否全部使用中文交付

## 7. 最终门禁脚本最低检查项

`scripts/check_final_gate.py` 至少应检查以下内容：

- 最终报告文件存在
- 存在 `配置上下文`
- 存在 `token 路径摘要`
- 存在 `主 Kernel Row 到代码映射表` 或 `Primary Kernel-to-Code Mapping Table`
- 存在 `覆盖摘要`
- 存在 `轻量性能说明`
- 存在 `后续输入`
- 覆盖摘要中存在 `Selected window row count`
- 覆盖摘要中存在 `Main compute total row count`
- 覆盖摘要中存在 `Main compute displayed layer instances`
- 覆盖摘要中存在 `Main compute folded layer instances`
- 覆盖摘要中存在 `Non-main-compute total row count`
- 覆盖摘要中存在 `Non-main-compute displayed row count`
- 覆盖摘要中存在 `Insufficient-evidence row count`
- 覆盖摘要中存在 `Coverage reconciliation note`
- 若 `state.json.flags.runtime_subphases_required = true`，则存在 `运行时子阶段摘要`
- 若 `state.json.flags.folding_used = true`，则存在 `重复层折叠说明`
- 若 `state.json.flags.has_unresolved_rows = true`，则存在 `未解析行`
- 若 `state.json.flags.last_layer_table_required = true`，则存在 `最后一层计算 Kernel Row 到代码映射表` 或 `Last-Layer Compute Row Mapping Table`
