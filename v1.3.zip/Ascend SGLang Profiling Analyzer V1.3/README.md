# Ascend SGLang Profiling 分析器

这个 skill 用于分析一个选定的 SGLang Ascend profiling 时间窗口，重建运行时代码路径，并输出以表格为中心的 kernel 到代码映射报告。

## 它现在怎么工作

- 先校验输入，再按固定顺序执行 4 个预处理脚本
- 结合启动参数、模型配置和代码，重建单 token 推理路径
- 同时分析 model forward 与运行时控制 / 调度 / graph 路径
- 对通用小 kernel 先做 owner 竞争，再做 profiling 到代码对齐
- 最后生成逐 kernel 的代码映射表，并补充轻量性能说明

## 它怎么用

必需输入：

- profiling 根路径，且 `ASCEND_PROFILER_OUTPUT/` 下必须有原始 `trace_view.json` 与 `kernel_details.csv`
- `window_start_ns` 与 `window_end_ns`
- 模型权重路径
- 本地代码仓路径
- 启动命令 / 脚本

可选输入：

- benchmark 命令
- benchmark 结果

使用规则：

- 必须先按用户提供的 ns 窗口切片，不能直接分析完整原始 profiling 抓取
- 窗口通常应覆盖一个完整 token 推理过程
- 对 speculative / MTP 场景，窗口通常应覆盖完整 `verify` 周期及匹配的 draft 工作

最小工作流：

1. 运行 `scripts/init_session.py` 初始化独立工作区
2. 每个关键 step 开始前运行 `scripts/pre_step_check.py`
3. 完成当前 step 的分析后，更新 `task_plan.md`、`findings.md`、`progress.md`
4. 运行 `scripts/mark_step_complete.py` 推进状态机
5. 最终报告生成后，运行 `scripts/check_final_gate.py`

## 输出长什么样

- 最终输出是一份中文 Markdown 报告
- 核心内容是 kernel 到代码映射表
- 表中凡是被展示的 kernel 行，都必须保持一行对应一个 kernel `row_id`
- 主计算部分允许按层实例折叠展示，但被保留层内部不得省略或合并 kernel 行
- 非主计算部分必须对所选窗口逐行完整保留

## 看哪个文件

- [SKILL.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/SKILL.md)：主规范入口，包含完整流程与各阶段注意事项
- [pipeline.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/references/pipeline.md)：状态机、阶段输入输出、完成标准与门禁
- [output_contract.md](file:///d:/Agent/Ascend-SGLang-Skills/skills/Ascend%20SGLang%20Profiling%20Analyzer%20V1.3/references/output_contract.md)：最终报告结构、表格粒度、coverage 对账与最终检查清单
